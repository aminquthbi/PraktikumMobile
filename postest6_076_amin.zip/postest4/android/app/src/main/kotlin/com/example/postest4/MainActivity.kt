package com.example.postest4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
