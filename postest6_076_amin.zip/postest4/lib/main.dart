import 'package:flutter/material.dart';
import 'package:postest4/main.dart';

void main() {
  runApp(
    new MaterialApp(
      home: new Home(),
      routes: <String, WidgetBuilder>{
        '/page1': (BuildContext context) => new Home(),
      },
    ),
  );
}

class Home extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ShowroomMotor(),
    );
  }
}

class ShowroomMotor extends StatefulWidget {
  @override
  _ShowroomMotorState createState() => _ShowroomMotorState();
}

class _ShowroomMotorState extends State<ShowroomMotor> {
  TextEditingController _namaController = TextEditingController();
  TextEditingController _merkController = TextEditingController();
  TextEditingController _hargaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Showroom Motor Jaya'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              controller: _namaController,
              decoration: InputDecoration(labelText: 'Nama Motor'),
            ),
            TextFormField(
              controller: _merkController,
              decoration: InputDecoration(labelText: 'Merk Motor'),
            ),
            TextFormField(
              controller: _hargaController,
              decoration: InputDecoration(labelText: 'Harga Motor'),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                String namaMotor = _namaController.text;
                String merkMotor = _merkController.text;
                String hargaMotor = _hargaController.text;

                // Lakukan sesuatu dengan data yang diinput
                // Misalnya, simpan data ke database atau tampilkan pesan
                print('Nama Motor: $namaMotor');
                print('Merk Motor: $merkMotor');
                print('Harga Motor: $hargaMotor');
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _namaController.dispose();
    _merkController.dispose();
    _hargaController.dispose();
    super.dispose();
  }
}
